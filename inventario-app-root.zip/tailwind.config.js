module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#E91E63",
        secondary: "#C2185B",
        background: "#FFFFFF",
        text: "#212121"
      },
    },
  },
  plugins: [],
};
