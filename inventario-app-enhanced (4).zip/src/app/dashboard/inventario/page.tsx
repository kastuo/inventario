'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';

export default function InventarioPage() {
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    fetch('/api/productos')
      .then(res => res.json())
      .then(setProductos);
  }, []);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-primary">Productos</h1>
        <Link href="/dashboard/inventario/nuevo" className="bg-primary text-white px-4 py-2 rounded hover:bg-secondary">
          + Nuevo producto
        </Link>
      </div>

      {productos.length === 0 ? (
        <p className="text-gray-600">No hay productos registrados.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {productos.map(p => (
            <Link
              key={p.id}
              href={`/dashboard/inventario/${p.id}`}
              className="block bg-white shadow rounded p-4 hover:shadow-md transition"
            >
              <h2 className="text-lg font-semibold text-primary">{p.nombre}</h2>
              <p className="text-sm text-gray-700">Cantidad disponible: <strong>{p.cantidad}</strong></p>
              <p className="text-xs text-gray-400 mt-1">Creado: {new Date(p.createdAt).toLocaleDateString()}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
