import { PrismaClient } from "@prisma/client";
import { NextResponse } from "next/server";

const prisma = new PrismaClient();

export async function GET() {
  const movimientos = await prisma.movimiento.findMany({
    include: { producto: true },
    orderBy: { fecha: 'desc' }
  });
  return NextResponse.json(movimientos);
}

export async function POST(req: Request) {
  const data = await req.json();
  const { tipo, cantidad, productoId } = data;

  await prisma.producto.update({
    where: { id: productoId },
    data: {
      cantidad: {
        increment: tipo === "entrada" ? cantidad : -cantidad,
      },
    },
  });

  const movimiento = await prisma.movimiento.create({
    data: { tipo, cantidad, productoId }
  });

  return NextResponse.json(movimiento);
}
