import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import Link from "next/link";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return <p className="text-center mt-10">Acceso no autorizado</p>;

  return (
    <div className="p-6 text-text bg-background min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Bienvenido {session.user.email}</h1>
      <ul className="space-y-4">
        <li>
          <Link href="/dashboard/inventario" className="text-primary underline">Ver productos</Link>
        </li>
        <li>
          <Link href="/dashboard/movimientos" className="text-primary underline">Ver movimientos</Link>
        </li>
        <li>
          <Link href="/dashboard/movimientos/nuevo" className="text-primary underline">Registrar entrada/salida</Link>
        </li>
      </ul>
    </div>
  );
}
