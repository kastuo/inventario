async function getProductos() {
  const res = await fetch("http://localhost:3000/api/productos", { cache: "no-store" });
  return res.json();
}

export default async function InventarioPage() {
  const productos = await getProductos();

  return (
    <div className="p-6 bg-background text-text min-h-screen">
      <h1 className="text-xl mb-4 font-semibold">Inventario</h1>
      <a href="/dashboard/inventario/nuevo" className="text-primary underline">+ Añadir producto</a>
      <ul className="mt-4 space-y-2">
        {productos.map((p: any) => (
          <li key={p.id} className="border p-2 rounded bg-white shadow">
            {p.nombre} - Cantidad: {p.cantidad}
          </li>
        ))}
      </ul>
    </div>
  );
}
