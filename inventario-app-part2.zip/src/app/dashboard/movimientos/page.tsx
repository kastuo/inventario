async function getMovimientos() {
  const res = await fetch("http://localhost:3000/api/movimientos", { cache: "no-store" });
  return res.json();
}

export default async function MovimientosPage() {
  const movimientos = await getMovimientos();

  return (
    <div className="p-6 bg-background text-text min-h-screen">
      <h1 className="text-xl mb-4 font-semibold">Historial de movimientos</h1>
      <ul className="space-y-2">
        {movimientos.map((m: any) => (
          <li key={m.id} className="border p-2 rounded bg-white shadow">
            [{m.tipo}] {m.producto.nombre} - {m.cantidad} unidades - {new Date(m.fecha).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
