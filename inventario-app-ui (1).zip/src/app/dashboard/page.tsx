'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function DashboardPage() {
  const [productos, setProductos] = useState([]);

  const cargarDatos = async () => {
    const res = await fetch('/api/productos');
    const data = await res.json();
    setProductos(data);
  };

  useEffect(() => {
    cargarDatos();
    const intervalo = setInterval(() => cargarDatos(), 5000);
    return () => clearInterval(intervalo);
  }, []);

  return (
    <div className="p-6 text-text bg-background min-h-screen">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-primary">Inventario en tiempo real</h1>
        <Link href="/dashboard/inventario/nuevo" className="text-sm text-white bg-primary px-4 py-2 rounded hover:bg-secondary">
          + Añadir producto
        </Link>
      </div>

      {productos.length === 0 ? (
        <p className="text-gray-500">No hay productos registrados.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {productos.map((producto: any) => (
            <div key={producto.id} className="bg-white rounded-lg shadow p-4">
              <h2 className="text-lg font-semibold text-primary">{producto.nombre}</h2>
              <p className="text-sm text-gray-700">Cantidad actual: <strong>{producto.cantidad}</strong></p>
              <p className="text-xs text-gray-400 mt-1">Actualizado: {new Date(producto.createdAt).toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
