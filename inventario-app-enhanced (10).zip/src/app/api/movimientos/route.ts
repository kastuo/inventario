import { PrismaClient } from '@prisma/client';
import { NextRequest, NextResponse } from 'next/server';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const productoId = searchParams.get("productoId");

  if (!productoId) {
    const movimientos = await prisma.movimiento.findMany({
      include: { producto: true },
      orderBy: { fecha: 'desc' }
    });
    return NextResponse.json(movimientos);
  }

  const movimientos = await prisma.movimiento.findMany({
    where: { productoId: parseInt(productoId) },
    orderBy: { fecha: 'desc' }
  });

  return NextResponse.json(movimientos);
}
