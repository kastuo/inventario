'use client';
import { useEffect, useState } from 'react';

export default function MovimientosPage() {
  const [movimientos, setMovimientos] = useState([]);
  const [productos, setProductos] = useState([]);
  const [mostrarModal, setMostrarModal] = useState(false);
  const [formData, setFormData] = useState({ productoId: '', tipo: 'entrada', cantidad: 0 });

  const cargarMovimientos = async () => {
    const res = await fetch('/api/movimientos');
    const data = await res.json();
    setMovimientos(data);
  };

  const cargarProductos = async () => {
    const res = await fetch('/api/productos');
    const data = await res.json();
    setProductos(data);
  };

  const registrarMovimiento = async () => {
    const producto = productos.find(p => p.id === parseInt(formData.productoId));
    if (formData.tipo === 'salida' && formData.cantidad > producto.cantidad) {
      alert('No puedes sacar más unidades de las que hay en stock.');
      return;
    }
    await fetch('/api/movimientos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tipo: formData.tipo,
        cantidad: Number(formData.cantidad),
        productoId: parseInt(formData.productoId),
      }),
    });

    setMostrarModal(false);
    setFormData({ productoId: '', tipo: 'entrada', cantidad: 0 });
    cargarMovimientos();
    cargarProductos();
  };

  useEffect(() => {
    cargarMovimientos();
    cargarProductos();
  }, []);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-primary">Historial de movimientos</h1>
        <button
          onClick={() => setMostrarModal(true)}
          className="bg-primary text-white px-4 py-2 rounded hover:bg-secondary"
        >
          + Registrar entrada/salida
        </button>
      </div>

      {movimientos.length === 0 ? (
        <p className="text-gray-600">No hay movimientos registrados.</p>
      ) : (
        <ul className="space-y-2">
          {movimientos.map((m) => (
            <li
              key={m.id}
              className={\`border-l-4 p-4 bg-white shadow rounded \${m.tipo === 'entrada' ? 'border-green-500' : 'border-red-500'}\`}
            >
              <div className="flex justify-between">
                <span className="text-sm font-medium">
                  [{m.tipo.toUpperCase()}] {m.cantidad} unidades
                </span>
                <span className="text-xs text-gray-500">{new Date(m.fecha).toLocaleString()}</span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Producto: <strong>{m.producto?.nombre || 'Sin nombre'}</strong>
              </p>
            </li>
          ))}
        </ul>
      )}

      {mostrarModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow max-w-md w-full relative">
            <button
              onClick={() => setMostrarModal(false)}
              className="absolute top-2 right-2 text-gray-400 hover:text-black text-xl"
            >
              &times;
            </button>
            <h2 className="text-xl font-bold mb-4 text-primary">Registrar movimiento</h2>

            <label className="block text-sm mb-1 font-medium">Producto:</label>
            <select
              value={formData.productoId}
              onChange={(e) => setFormData({ ...formData, productoId: e.target.value })}
              className="w-full border px-3 py-2 rounded mb-4"
            >
              <option value="">Selecciona un producto</option>
              {productos.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.nombre} (Stock: {p.cantidad})
                </option>
              ))}
            </select>

            <label className="block text-sm mb-1 font-medium">Tipo:</label>
            <select
              value={formData.tipo}
              onChange={(e) => setFormData({ ...formData, tipo: e.target.value })}
              className="w-full border px-3 py-2 rounded mb-4"
            >
              <option value="entrada">Entrada</option>
              <option value="salida">Salida</option>
            </select>

            <label className="block text-sm mb-1 font-medium">Cantidad:</label>
            <input
              type="number"
              value={formData.cantidad}
              onChange={(e) => setFormData({ ...formData, cantidad: parseInt(e.target.value) })}
              className="w-full border px-3 py-2 mb-4 rounded"
            />

            <button
              onClick={registrarMovimiento}
              className="bg-primary text-white px-4 py-2 rounded hover:bg-secondary w-full"
            >
              Registrar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
