'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function MovimientosPage() {
  const [movimientos, setMovimientos] = useState([]);

  useEffect(() => {
    fetch('/api/movimientos')
      .then(res => res.json())
      .then(setMovimientos);
  }, []);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-primary">Historial de movimientos</h1>
        <Link href="/dashboard/movimientos/nuevo" className="bg-primary text-white px-4 py-2 rounded hover:bg-secondary">
          + Registrar entrada/salida
        </Link>
      </div>

      {movimientos.length === 0 ? (
        <p className="text-gray-600">No hay movimientos registrados.</p>
      ) : (
        <ul className="space-y-2">
          {movimientos.map(m => (
            <li key={m.id} className={`border-l-4 p-4 bg-white shadow rounded ${
              m.tipo === 'entrada' ? 'border-green-500' : 'border-red-500'
            }`}>
              <div className="flex justify-between">
                <span className="text-sm font-medium">
                  [{m.tipo.toUpperCase()}] {m.cantidad} unidades
                </span>
                <span className="text-xs text-gray-500">
                  {new Date(m.fecha).toLocaleString()}
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Producto: <strong>{m.producto?.nombre || 'Sin nombre'}</strong>
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
